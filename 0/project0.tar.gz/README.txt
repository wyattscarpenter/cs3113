Project 0

Name: Wyatt S Carpenter

Email address: w@ou.edu

Date: Wed Sep  5 01:23:47 UTC 2018

Description
To solve this programming problem, I essentially used an array of 256 ints, one for each possible byte. As I read bytes from stdin, I incremented the appropriate int. Then, I printed the appropriate characters using printf and for loops.

References
For this project, I used no references beyond the man pages and the information presented in class.
